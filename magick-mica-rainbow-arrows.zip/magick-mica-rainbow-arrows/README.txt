MAGICK MICA RAINBOW ARROWS
A free set of 8 cursors: red, orange, yellow, green, blue, indigo, violet, rainbow.

WHAT'S INSIDE
Each color has its own folder with:
  magick-mica-arrow-<color>-64.png    start with this one
  magick-mica-arrow-<color>-32.png    closest to a normal cursor's size
  magick-mica-arrow-<color>-128.png   full detail
  magick-mica-arrow-<color>.svg       editable master drawing
magick-mica-rainbow-arrows-preview.png shows them all on light and dark.

HOW TO USE
On Substack or any site with a "Custom cursor" upload:
upload the 64px PNG. If it looks too big, use the 32px one.

On your own website (CSS):
  body { cursor: url("magick-mica-arrow-violet-32.png") 1 1, auto; }
The "1 1" is the click point (the arrow's tip). Use 2 2 for the 64px file
and 3 3 for the 128px file. Keep "auto" at the end as a fallback.

The 32px and 64px versions are drawn simpler on purpose
(fewer sparkles, thicker outline), so they stay sharp at small sizes.

TERMS
Free to use as your cursor on your own site, newsletter or profile.
Please don't resell them or repackage them as your own set.

Made by Magick Mica · https://magickmica.github.io
